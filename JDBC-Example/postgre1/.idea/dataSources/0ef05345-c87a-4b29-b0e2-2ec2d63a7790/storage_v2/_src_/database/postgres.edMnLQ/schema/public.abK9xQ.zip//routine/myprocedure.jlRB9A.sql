create procedure myprocedure(integer, character, character, integer, timestamp without time zone, character)
  language plpgsql
as
$$
begin
	insert into worker values ($1,$2,$3,$4,$5,$6);
end;
$$;

alter procedure myprocedure(integer, char, char, integer, timestamp, char) owner to postgres;

